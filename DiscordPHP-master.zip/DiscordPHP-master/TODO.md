## Todo

- Handle Websocket close codes
- Handle Discord opcode 7 (Connect to specified gateway)
	- Handle Websocket code `1012` (Reconnect to same gateway)
- Test all events properly
- More that I can't remember...